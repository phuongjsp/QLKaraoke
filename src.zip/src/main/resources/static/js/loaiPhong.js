let loaiPhong = [];
const iapResource = 'http://localhost:8080/api/';
$.get(`${iapResource}loai-phong`,(res, status) => {
    $('#danh-sach-loai-phong').html('');
    loaiPhong = res;
    $.each(res,(index, loaiPhong) => {
        $('#danh-sach-loai-phong').append(createLoaiPhong(loaiPhong.id, loaiPhong.loaiPhong));
    })
});
function createLoaiPhong(id, loaiPhong) {
    return `<li class="list-group-item row" id="loai-phong-${id}">
                               <button class="col-6 btn btn-success"  onclick="getByLoaiPhong(${id});">${loaiPhong}</button>
                               <button class="col-3 btn btn-info"  onclick="setUpdateLoaiPhong(${id})"
                                data-toggle="modal" data-target="#update-loai-vip">
                                   <i class="fa fa-edit"></i>
                               </button>
                                <button class="col-2 btn btn-danger" onclick="xoaLoaiPhong(${id})"><i class="fa fa-trash"></i></button>
                                    </li>`;
}
function setUpdateLoaiPhong(id) {
    let loaiPhongUpdate = loaiPhong.filter(lp => lp.id === id);
    $('#id-loai-phong').val(id);
    $('#ten-loai-phong').val(loaiPhongUpdate[0].loaiPhong);
    $('#gia-loai-phong').val(loaiPhongUpdate[0].tienPhongTrenGio);
    $('#btn-update-loai-phong').removeClass('d-none');
    $('#btn-new-loai-phong').addClass('d-none');

}

function onUpdateLoaiPhong() {
    let data = {id: parseInt($('#id-loai-phong').val()), loaiPhong:  $('#ten-loai-phong').val(), tienPhongTrenGio: parseInt($('#gia-loai-phong').val())};
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: `${iapResource}update-loai-phong`,
        data: JSON.stringify(data),
        dataType: 'json',
        timeout: 600000,
        success: function (data) {
            $.each(loaiPhong, (index, value) => loaiPhong[index] = value.id === data.id ? data : loaiPhong[index]);
            $(`#loai-phong-${data.id}`).html(`<button class="col-6 btn btn-success" >${data.loaiPhong}</button>
                               <button class="col-3 btn btn-info"  onclick="setUpdateLoaiPhong(${data.id})"
                                data-toggle="modal" data-target="#update-loai-vip">
                                   <i class="fa fa-edit"></i>
                               </button>
                                <button class="col-2 btn btn-danger" onclick="xoaLoaiPhong(${data.id})"><i class="fa fa-trash"></i></button>`);
        },
        error: function (e) {
            console.log(e);
        }
    });
}
function newLoaiPhong() {
    $('#btn-new-loai-phong').removeClass('d-none');
    $('#btn-update-loai-phong').addClass('d-none');
    $('#id-loai-phong').val(null);
    $('#ten-loai-phong').val('');
    $('#gia-loai-phong').val('');
}

function pushNewLoaiPhong() {
    let data = {id: 0, loaiPhong:  $('#ten-loai-phong').val(), tienPhongTrenGio: parseInt($('#gia-loai-phong').val())};
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: `${iapResource}loai-phong`,
        data: JSON.stringify(data),
        dataType: 'json',
        timeout: 600000,
        success: data => {
            $('#danh-sach-loai-phong').append(createLoaiPhong(data.id, data.loaiPhong));
            loaiPhong.push(data);
        }
    });
}
function xoaLoaiPhong(id) {
    $.get(`${iapResource}xoa-loai-phong/${id}`,(res, status) => {
        $(`#loai-phong-${id}`).remove();
    });
}
