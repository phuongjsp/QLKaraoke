package levantuan.quanlykaraoke.controller;

import levantuan.quanlykaraoke.config.Layout;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PhongHatController {

    @Layout(value = "default", title = "Phong hat")
    @GetMapping("phong-hat")
    public String list() {
        return "phongHat/danhSach";
    }

    @Layout(value = "default", title = "Phong hat")
    @GetMapping("phong-hat/new")
    public String update() {

        return "phongHat/update";
    }
    @Layout(value = "default", title = "Phong hat")
    @GetMapping("vat-tu")
    public String vatTuView() { return "phongHat/vatTu"; }

    @Layout(value = "default", title = "Phong hat")
    @GetMapping("vip")
    public String vipView() {
        return "phongHat/vip";
    }

    @Layout(value = "default", title = "Phong hat")
    @GetMapping("khach-hang")
    public String khachhangView() {
        return "phongHat/khachhang";
    }

    @Layout(value = "default", title = "Phong hat")
    @GetMapping("dich-vu")
    public String dichVuView() { return "phongHat/dichvu"; }

}
