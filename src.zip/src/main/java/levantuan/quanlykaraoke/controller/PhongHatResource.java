package levantuan.quanlykaraoke.controller;

import levantuan.quanlykaraoke.dto.PhongDTO;
import levantuan.quanlykaraoke.entities.Phong;
import levantuan.quanlykaraoke.service.PhongHatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api")
public class PhongHatResource {

    @Autowired
    private PhongHatService phongHatService;

    @GetMapping("phong-hat/getAll/{id}")
    public Page<Phong> getAllPhong(@PathVariable Integer id,
                                   @RequestParam Integer pageNumber,
                                   @RequestParam Integer pageSize) {
        return phongHatService.getALlPhong(id, pageNumber -1, pageSize);
    }

    @GetMapping("phong-hat/get/{id}")
    public PhongDTO getPhongById(@PathVariable Long id) {
        return phongHatService.getById(id);
    }
}
