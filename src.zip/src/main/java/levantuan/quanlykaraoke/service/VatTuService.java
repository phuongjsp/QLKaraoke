package levantuan.quanlykaraoke.service;

import levantuan.quanlykaraoke.entities.VatTu;

import java.util.List;

public interface VatTuService {

    List<VatTu> getAllVatTu();

    VatTu updateVatTu(VatTu vatTu);

    VatTu newVatTu(VatTu vatTu);

    boolean xoaVatTu(Long id);

    List<VatTu> getAllVatTuByIdPhong(Long idPhong);
}
