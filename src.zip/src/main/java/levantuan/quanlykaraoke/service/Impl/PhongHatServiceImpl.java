package levantuan.quanlykaraoke.service.Impl;

import levantuan.quanlykaraoke.dto.PhongDTO;
import levantuan.quanlykaraoke.entities.ChiTietVatTu;
import levantuan.quanlykaraoke.entities.LoaiPhong;
import levantuan.quanlykaraoke.entities.Phong;
import levantuan.quanlykaraoke.entities.VatTu;
import levantuan.quanlykaraoke.repositories.ChiTietVatTuRepository;
import levantuan.quanlykaraoke.repositories.LoaiPhongRepository;
import levantuan.quanlykaraoke.repositories.PhongRepository;
import levantuan.quanlykaraoke.service.PhongHatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class PhongHatServiceImpl implements PhongHatService {

    @Autowired
    private LoaiPhongRepository loaiPhongRepository;

    @Autowired
    private ChiTietVatTuRepository chiTietVatTuRepository;

    @Autowired
    private PhongRepository phongRepository;
    @Override
    public List<LoaiPhong> getAllLoaiPhong() {
        return loaiPhongRepository.findAll();
    }

    @Override
    public LoaiPhong updateLoaiPhong(LoaiPhong loaiPhong) {
        LoaiPhong lp = loaiPhongRepository.getOne(loaiPhong.getId());
        lp.setLoaiPhong(loaiPhong.getLoaiPhong());
        lp.setTienPhongTrenGio(loaiPhong.getTienPhongTrenGio());
        loaiPhongRepository.save(loaiPhong);
        return loaiPhong;
    }

    @Override
    public LoaiPhong newLoaiPhong(LoaiPhong loaiPhong) {
        LoaiPhong lp = new LoaiPhong();
        lp.setLoaiPhong(loaiPhong.getLoaiPhong());
        lp.setTienPhongTrenGio(loaiPhong.getTienPhongTrenGio());
        return loaiPhongRepository.save(lp);
    }

    @Override
    public boolean xoaLoaiPhong(Long id) {
        try {
            loaiPhongRepository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public Page<Phong> getALlPhong(Integer id, Integer page, Integer size) {
        if (Objects.isNull(id) || id == 0) {
            return phongRepository.findAll(PageRequest.of(page, size));
        } else {
            return phongRepository.findAllByIdLoaiPhong(id, PageRequest.of(page, size));
        }
    }

    @Override
    public PhongDTO getById(Long idPhong) {
        PhongDTO phongDTO = new PhongDTO(phongRepository.getOne(idPhong));
        phongDTO.setVatTus(new ArrayList<>(chiTietVatTuRepository.findAllChiTietVatTuByPhongId(idPhong)));
        return phongDTO;
    }

    @Override
    public Phong newPhong(PhongDTO phong) {
        return savePhong(new Phong(), phong);
    }

    @Override
    public Phong updatePhong(PhongDTO phong) {
        return savePhong(phongRepository.getOne(phong.getId()), phong);
    }

    private Phong savePhong(Phong p, PhongDTO phong) {
        p.setMaPhong(phong.getMaPhong());
        p.setTinhTrangPhong(phong.getTinhTrangPhong());
        p.setLoaiPhong(loaiPhongRepository.getOne(phong.getIdLoaiPhong()));
        return phongRepository.save(p);
    }
    @Override
    public boolean deletePhong(Long idPhong) {
         Integer xxx = phongRepository.deletePhongById(idPhong);
        System.out.println(xxx);
        return xxx == 0;
    }
}
