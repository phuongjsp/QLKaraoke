package levantuan.quanlykaraoke.repositories;

import levantuan.quanlykaraoke.entities.ChiTietVatTu;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChiTietVatTuRepository extends JpaRepository<ChiTietVatTu,Long> {

    @Query(nativeQuery = true, value = " select * from chi_tiet_vat_tu v where v.phong = ?1 ")
    List<ChiTietVatTu> findAllChiTietVatTuByPhongId(Long id);

}
