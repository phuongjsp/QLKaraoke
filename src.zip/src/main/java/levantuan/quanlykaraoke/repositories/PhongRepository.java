package levantuan.quanlykaraoke.repositories;

import levantuan.quanlykaraoke.entities.Phong;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PhongRepository extends JpaRepository<Phong,Long> {

    @Modifying //chỉ dùng khi update và delete
    @Query(nativeQuery = true, value = "delete from phong where id = :id")
    Integer  deletePhongById(@Param("id") Long id);


    @Query(value = "select * from phong  where loai_phong = ?1 ", nativeQuery = true)
    Page<Phong> findAllByIdLoaiPhong(Integer id, Pageable pageable);
}
